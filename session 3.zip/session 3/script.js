 function sayHello(name, place) {
     //body of the function
     console.log("Hello world " + name + " from " + place);
     
     let template = `<h2>A big hello to ${name} from <span class="place"> ${place}</span></h2>`;
     return template;
 }

 let billInfo = sayHello("Colin", "Virginia");

 document.write(billInfo);

 sayHello("Jerry", "Ohio");

 document.write(sayHello("Arturo ", " Mexico"))




 function countToTen() {
     for (let x = 1; x < 10; x++)
         document.write(x, prompt = " ")
 }
 countToTen();

 let y = " the ten crack commandments"
 document.write(y)