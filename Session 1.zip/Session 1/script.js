console.log("Script");
var client="Colin";//step 1=declaration /can change
client="Colin";//step 2= assignation 
let age=99;//can change
const URL="http://127.0.0.1/iot";//can't change
age=55;

console.log(age);
console.log(URL);
client="Ping Pong";

client="Colin";

console.log("client");//client
console.log(client);//Colin
console.log("Please, "+ client + " visit the site:"+URL);

let jobTitle="Bricklayer";
let geoLocation="Timbuktu";
let partnerName="your mama";
let numberChildren=99;

console.log("You will be a " + jobTitle + " in " + geoLocation + ", and married to " + partnerName + " with " + numberChildren + " kids.");

console.log("client");//client
//console.log("Please, " + client + "visit the site:URL);
//template string
console.log(`Please, ${client} visit the site: ${URL}`);

document.write(`Please, ${client} visit the site: ${URL}`);