let firstName="Colin" 
let lastName="Ochs" 
let middleInitial="D"
let numberChildren="2"
let motherName="Janelle"
let fatherName="Paul"
let age=39
let height=6
let weight=200
let hairColor="Blond" 
let eyeColor="Brown"
let shoeSize=12
let birthState="Virginia"
let currentState="Tennessee"
let favoriteColor="orange" 
let favoriteFood="Candy"
let favoriteMusic="Rock" 
let make="Honda"
let model="Prelude"
let carColor="red"

document.write(`${firstName} ${middleInitial} ${lastName} 
has ${numberChildren} children.  His parents are ${fatherName}
 and ${motherName}.  He is ${age} years old.  He is ${height} feet and 
 2in tall, weighing ${weight}lbs.  His hair is ${hairColor} and 
 his eyes are ${eyeColor}.  He wears a size ${shoeSize} shoe. ${firstName} 
 was born in ${birthState} but now resides in ${currentState}.  His favorite
 color is ${favoriteColor}, his favorite food is ${favoriteFood} and he 
 generally listens to ${favoriteMusic} music.  His first car was a ${carColor} ${make} ${model}.`)