let product=prompt("Enter the Product:");
let quantity=prompt("Enter the Quantity:");

let x;
x = prompt("Enter the Price:");
var result= Number(x)*Number(.10) + Number(x);

console.log(product);
console.log(quantity);
console.log(x);
console.log(result);

document.write(`<p>product: ${product}</p>`);
document.write(`<p>quantity: ${quantity}</P>`);
document.write(`<p>price: ${x}`);
document.write(`<p>total cost per item: $ ${result}</p>`);

document.write("<p>Tennessee sales tax is 10%</p>");

